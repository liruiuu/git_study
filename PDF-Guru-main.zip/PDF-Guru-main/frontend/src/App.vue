<template>
  <HelloWorld />
  <Main />
</template>

<script lang="ts" setup>
import Main from './Main.vue'
</script>

